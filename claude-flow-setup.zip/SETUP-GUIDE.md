# Claude-Flow Setup with Local Inference (Ollama)

A complete guide to installing claude-flow and configuring it to use your local Ollama inference engine for agent work.

## TL;DR - How It Works

**Claude-flow supports TWO modes:**

1. **API Mode** - Uses `ANTHROPIC_API_KEY` for direct Anthropic API calls (costs money)
2. **Local Mode** - Routes through Ollama's Anthropic-compatible API (free, uses your GPU)

The good news: Ollama v0.14.0+ now supports Anthropic Messages API compatibility, which means Claude Code can interact with any Ollama model. This means claude-flow's agent calls can be routed to your local models!

---

## Prerequisites

### 1. Ollama Installed and Running

```bash
# Check if Ollama is installed
ollama --version

# If not, install it (Windows/WSL)
curl -fsSL https://ollama.com/install.sh | sh

# Start Ollama server
ollama serve
```

### 2. Pull Recommended Models

Claude Code requires a large context window. We recommend at least 64k tokens.

```bash
# Best coding models for agent work
ollama pull qwen3-coder        # Excellent for coding tasks
ollama pull glm-4.7            # Good general purpose
ollama pull deepseek-coder-v2  # Alternative coder

# For your 5090, you can run larger models
ollama pull qwen3-coder:32b    # If you have VRAM headroom
```

### 3. Claude Code Installed

```bash
# Install Claude Code
npm install -g @anthropic-ai/claude-code

# Or via curl
curl -fsSL https://claude.ai/install.sh | bash
```

---

## Quick Setup (Ollama Native)

The simplest approach - Ollama's quick setup just runs `ollama launch claude`:

```bash
# This configures everything automatically
ollama launch claude --config

# Or set environment variables manually
export ANTHROPIC_AUTH_TOKEN=ollama
export ANTHROPIC_API_KEY=""
export ANTHROPIC_BASE_URL=http://localhost:11434

# Then run Claude Code with your model
claude --model qwen3-coder
```

---

## Install Claude-Flow

```bash
# Install claude-flow v3 alpha (latest with all features)
npm install -g claude-flow@v3alpha

# Or use npx (no global install)
npx claude-flow@v3alpha init

# Initialize in your project
cd ~/your-project
npx claude-flow@v3alpha init
```

---

## Configure Claude-Flow for Local Inference

### Option A: Environment Variables (Simplest)

Add to your `~/.bashrc` or `~/.zshrc`:

```bash
# Route Claude Code/claude-flow to Ollama
export ANTHROPIC_AUTH_TOKEN=ollama
export ANTHROPIC_API_KEY=""
export ANTHROPIC_BASE_URL=http://localhost:11434
export ANTHROPIC_MODEL=qwen3-coder

# Optional: Increase timeout for local inference
export BASH_DEFAULT_TIMEOUT_MS=300000
export MCP_TIMEOUT=300000
```

Then reload:
```bash
source ~/.bashrc
```

### Option B: Claude Code Settings File

Create/edit `~/.claude/settings.json`:

```json
{
  "env": {
    "ANTHROPIC_BASE_URL": "http://localhost:11434",
    "ANTHROPIC_AUTH_TOKEN": "ollama",
    "ANTHROPIC_API_KEY": ""
  },
  "model": "qwen3-coder",
  "theme": "dark"
}
```

### Option C: LiteLLM Proxy (Advanced - Multi-Model Routing)

LiteLLM acts as a universal LLM gateway that enables Claude Code to route requests to multiple non-Anthropic models while maintaining the same interface.

This is useful if you want intelligent routing between local and cloud models.

Create `~/.litellm/config.yaml`:

```yaml
model_list:
  # Local Ollama models (free)
  - model_name: "local-coder"
    litellm_params:
      model: "ollama/qwen3-coder"
      api_base: http://localhost:11434
  
  - model_name: "local-reasoning"
    litellm_params:
      model: "ollama/deepseek-r1:14b"
      api_base: http://localhost:11434
  
  # Cloud fallback (for when you need it)
  - model_name: "claude-sonnet"
    litellm_params:
      model: "anthropic/claude-sonnet-4-5-20250929"
      api_key: ${ANTHROPIC_API_KEY}

general_settings:
  master_key: "sk-local-dev-key"
  request_timeout: 600

litellm_settings:
  drop_params: true
```

Start the proxy:
```bash
pip install litellm
litellm --config ~/.litellm/config.yaml --port 4000
```

Then configure claude-flow:
```bash
export ANTHROPIC_BASE_URL="http://localhost:4000"
export ANTHROPIC_AUTH_TOKEN="sk-local-dev-key"
```

---

## Claude-Flow Provider Configuration

Claude-flow has its own provider system. Create `.claude-flow/config.json` in your project:

```json
{
  "providers": {
    "default": "ollama",
    "ollama": {
      "type": "ollama",
      "baseUrl": "http://localhost:11434",
      "models": {
        "coder": "qwen3-coder",
        "reasoning": "deepseek-r1:14b",
        "fast": "qwen3-coder:7b"
      },
      "defaultModel": "qwen3-coder"
    },
    "anthropic": {
      "type": "anthropic",
      "apiKey": "${ANTHROPIC_API_KEY}",
      "models": {
        "opus": "claude-opus-4-5-20251101",
        "sonnet": "claude-sonnet-4-5-20250929"
      }
    }
  },
  "routing": {
    "strategy": "cost-based",
    "rules": [
      {
        "taskType": "simple-edit",
        "provider": "ollama",
        "model": "fast"
      },
      {
        "taskType": "coding",
        "provider": "ollama",
        "model": "coder"
      },
      {
        "taskType": "architecture",
        "provider": "anthropic",
        "model": "opus"
      }
    ]
  }
}
```

---

## Verify Setup

### Test Ollama directly:
```bash
# Check Ollama is running
curl http://localhost:11434/api/tags

# Test a completion
curl http://localhost:11434/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen3-coder",
    "messages": [{"role": "user", "content": "Hello"}]
  }'
```

### Test Claude Code with Ollama:
```bash
# Should use your local model
claude --model qwen3-coder -p "What model are you?"
```

### Test Claude-Flow:
```bash
# Initialize and check status
npx claude-flow@v3alpha init
npx claude-flow@v3alpha mcp status

# Run a simple agent task
npx claude-flow@v3alpha --agent coder --task "Create a hello world function"
```

---

## WSL-Specific Configuration

Since you're running WSL on Windows with your 5090:

### 1. Ensure Ollama binds to correct interface

⚠️ Critical Gotcha: Ollama binds to localhost by default — Docker containers get "connection refused". Export OLLAMA_HOST=0.0.0.0:11434 before running ollama serve.

```bash
# Add to ~/.bashrc
export OLLAMA_HOST=0.0.0.0:11434
```

### 2. Pre-warm models (avoid timeout on first call)

Ollama loads models lazily on first request. Claude Code times out waiting for the first response.

```bash
# Create a warmup script
cat > ~/warmup-ollama.sh << 'EOF'
#!/bin/bash
echo "Warming up Ollama models..."
curl -s http://localhost:11434/api/generate -d '{"model":"qwen3-coder","prompt":"hi","stream":false}' > /dev/null
echo "Models ready!"
EOF
chmod +x ~/warmup-ollama.sh

# Run before starting work
~/warmup-ollama.sh
```

### 3. GPU Memory Management

With your 5090, you have plenty of VRAM. Set Ollama to use it efficiently:

```bash
# Allow larger context windows
export OLLAMA_NUM_CTX=65536  # 64k context

# Use all available VRAM
export OLLAMA_GPU_LAYERS=999
```

---

## Running Claude-Flow Agents Overnight

Now combine with the Night Architecture system:

```bash
# Start Ollama in background
nohup ollama serve > /dev/null 2>&1 &

# Warmup models
~/warmup-ollama.sh

# Run overnight agents
cd ~/your-project
./run-overnight.sh --max-hours 8 --max-iterations 50
```

---

## Troubleshooting

### "Connection refused"
```bash
# Check Ollama is running
pgrep -f "ollama serve"

# Restart if needed
pkill ollama
export OLLAMA_HOST=0.0.0.0:11434
ollama serve &
```

### "Model not found"
```bash
# List available models
ollama list

# Pull the model if missing
ollama pull qwen3-coder
```

### "Timeout" errors
```bash
# Increase timeouts
export BASH_DEFAULT_TIMEOUT_MS=600000
export MCP_TIMEOUT=600000

# Pre-warm the model
curl http://localhost:11434/api/generate -d '{"model":"qwen3-coder","prompt":"warmup"}'
```

### Tool calling not working
Some models don't support tool calling well. Use models that do:
- ✅ qwen3-coder (excellent tool support)
- ✅ glm-4.7 (good tool support)
- ⚠️ deepseek-coder (limited tool support)
- ❌ llama2 (no tool support)

---

## Cost Comparison

| Mode | Cost | Latency | Quality |
|------|------|---------|---------|
| Local (Ollama + qwen3-coder) | $0 | 1-5s | 85% of Claude |
| API (Claude Sonnet) | ~$3/1M tokens | 0.5-2s | 100% |
| API (Claude Opus) | ~$15/1M tokens | 1-3s | Best |

For overnight agent work, local inference is ideal - zero cost, unlimited usage!

---

## Complete Setup Script

Save this as `setup-claude-flow-local.sh`:

```bash
#!/bin/bash
set -e

echo "🦇 Night Architecture - Claude-Flow Local Setup"
echo "================================================"

# Check Ollama
if ! command -v ollama &> /dev/null; then
    echo "Installing Ollama..."
    curl -fsSL https://ollama.com/install.sh | sh
fi

# Start Ollama if not running
if ! pgrep -f "ollama serve" > /dev/null; then
    echo "Starting Ollama..."
    export OLLAMA_HOST=0.0.0.0:11434
    nohup ollama serve > /tmp/ollama.log 2>&1 &
    sleep 3
fi

# Pull recommended models
echo "Pulling coding models..."
ollama pull qwen3-coder

# Configure environment
echo "Configuring environment..."
cat >> ~/.bashrc << 'EOF'

# Claude-Flow Local Inference
export OLLAMA_HOST=0.0.0.0:11434
export OLLAMA_NUM_CTX=65536
export ANTHROPIC_AUTH_TOKEN=ollama
export ANTHROPIC_API_KEY=""
export ANTHROPIC_BASE_URL=http://localhost:11434
export ANTHROPIC_MODEL=qwen3-coder
export BASH_DEFAULT_TIMEOUT_MS=300000
export MCP_TIMEOUT=300000
EOF

source ~/.bashrc

# Install claude-flow
echo "Installing claude-flow..."
npm install -g claude-flow@v3alpha

# Warmup
echo "Warming up models..."
curl -s http://localhost:11434/api/generate \
  -d '{"model":"qwen3-coder","prompt":"hello","stream":false}' > /dev/null

echo ""
echo "✅ Setup complete!"
echo ""
echo "Test with: claude --model qwen3-coder -p 'Hello'"
echo "Or: npx claude-flow@v3alpha --agent coder --task 'Create hello world'"
```

Run it:
```bash
chmod +x setup-claude-flow-local.sh
./setup-claude-flow-local.sh
```

---

## Summary

**Claude-flow uses API tokens by default**, but you can route everything through Ollama by setting:

```bash
export ANTHROPIC_BASE_URL=http://localhost:11434
export ANTHROPIC_AUTH_TOKEN=ollama
```

This gives you the full claude-flow multi-agent system running on your local 5090 for free! Perfect for overnight autonomous development loops.

🦇 Happy night coding!
