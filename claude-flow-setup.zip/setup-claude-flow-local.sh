#!/bin/bash
#
# Claude-Flow + Ollama Local Setup Script
# For WSL/Linux with NVIDIA GPU
#
# This script sets up claude-flow to use your local Ollama instance
# for free, unlimited agent operations.
#

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

echo ""
echo -e "${PURPLE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${PURPLE}║                                                                ║${NC}"
echo -e "${PURPLE}║   🦇  CLAUDE-FLOW + OLLAMA LOCAL SETUP  🦇                     ║${NC}"
echo -e "${PURPLE}║                                                                ║${NC}"
echo -e "${PURPLE}║   Free, unlimited agent operations on your GPU                 ║${NC}"
echo -e "${PURPLE}║                                                                ║${NC}"
echo -e "${PURPLE}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Detect shell config file
if [ -n "$ZSH_VERSION" ]; then
    SHELL_RC="$HOME/.zshrc"
elif [ -n "$BASH_VERSION" ]; then
    SHELL_RC="$HOME/.bashrc"
else
    SHELL_RC="$HOME/.bashrc"
fi

echo -e "${BLUE}Shell config: $SHELL_RC${NC}"
echo ""

# Step 1: Check/Install Ollama
echo -e "${CYAN}Step 1: Checking Ollama...${NC}"
if command -v ollama &> /dev/null; then
    OLLAMA_VERSION=$(ollama --version 2>/dev/null || echo "unknown")
    echo -e "${GREEN}✓ Ollama found: $OLLAMA_VERSION${NC}"
else
    echo -e "${YELLOW}Installing Ollama...${NC}"
    curl -fsSL https://ollama.com/install.sh | sh
    echo -e "${GREEN}✓ Ollama installed${NC}"
fi

# Step 2: Start Ollama server
echo ""
echo -e "${CYAN}Step 2: Starting Ollama server...${NC}"
export OLLAMA_HOST=0.0.0.0:11434

if pgrep -f "ollama serve" > /dev/null; then
    echo -e "${GREEN}✓ Ollama already running${NC}"
else
    echo -e "${YELLOW}Starting Ollama...${NC}"
    nohup ollama serve > /tmp/ollama.log 2>&1 &
    sleep 3
    
    if pgrep -f "ollama serve" > /dev/null; then
        echo -e "${GREEN}✓ Ollama started${NC}"
    else
        echo -e "${RED}✗ Failed to start Ollama. Check /tmp/ollama.log${NC}"
        exit 1
    fi
fi

# Step 3: Pull recommended models
echo ""
echo -e "${CYAN}Step 3: Pulling coding models...${NC}"
echo -e "${BLUE}This may take a while for the first download...${NC}"

# Check if model exists before pulling
if ollama list 2>/dev/null | grep -q "qwen3-coder"; then
    echo -e "${GREEN}✓ qwen3-coder already available${NC}"
else
    echo -e "${YELLOW}Pulling qwen3-coder (recommended for coding)...${NC}"
    ollama pull qwen3-coder
    echo -e "${GREEN}✓ qwen3-coder pulled${NC}"
fi

# Step 4: Check/Install Node.js
echo ""
echo -e "${CYAN}Step 4: Checking Node.js...${NC}"
if command -v node &> /dev/null; then
    NODE_VERSION=$(node --version)
    echo -e "${GREEN}✓ Node.js found: $NODE_VERSION${NC}"
else
    echo -e "${YELLOW}Node.js not found. Please install Node.js 18+ first.${NC}"
    echo "  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -"
    echo "  sudo apt-get install -y nodejs"
    exit 1
fi

# Step 5: Install Claude Code
echo ""
echo -e "${CYAN}Step 5: Checking Claude Code...${NC}"
if command -v claude &> /dev/null; then
    echo -e "${GREEN}✓ Claude Code found${NC}"
else
    echo -e "${YELLOW}Installing Claude Code...${NC}"
    npm install -g @anthropic-ai/claude-code
    echo -e "${GREEN}✓ Claude Code installed${NC}"
fi

# Step 6: Install Claude-Flow
echo ""
echo -e "${CYAN}Step 6: Installing Claude-Flow v3...${NC}"
npm install -g claude-flow@v3alpha 2>/dev/null || {
    echo -e "${YELLOW}Installing via npx instead...${NC}"
}
echo -e "${GREEN}✓ Claude-Flow available${NC}"

# Step 7: Configure environment
echo ""
echo -e "${CYAN}Step 7: Configuring environment...${NC}"

# Check if already configured
if grep -q "CLAUDE-FLOW LOCAL INFERENCE" "$SHELL_RC" 2>/dev/null; then
    echo -e "${GREEN}✓ Environment already configured in $SHELL_RC${NC}"
else
    echo -e "${YELLOW}Adding configuration to $SHELL_RC...${NC}"
    
    cat >> "$SHELL_RC" << 'ENVCONFIG'

# ═══════════════════════════════════════════════════════════════
# CLAUDE-FLOW LOCAL INFERENCE CONFIGURATION
# Added by setup script - routes Claude Code/flow through Ollama
# ═══════════════════════════════════════════════════════════════

# Ollama server binding
export OLLAMA_HOST=0.0.0.0:11434
export OLLAMA_NUM_CTX=65536  # 64k context for coding

# Route Claude Code to Ollama
export ANTHROPIC_AUTH_TOKEN=ollama
export ANTHROPIC_API_KEY=""
export ANTHROPIC_BASE_URL=http://localhost:11434
export ANTHROPIC_MODEL=qwen3-coder

# Increase timeouts for local inference
export BASH_DEFAULT_TIMEOUT_MS=300000
export MCP_TIMEOUT=300000

# Helper function to warmup models
warmup-ollama() {
    echo "🔥 Warming up Ollama models..."
    curl -s http://localhost:11434/api/generate \
        -d '{"model":"qwen3-coder","prompt":"warmup","stream":false}' > /dev/null
    echo "✓ Models ready!"
}

# Helper function to start local agent session
start-agents() {
    # Ensure Ollama is running
    if ! pgrep -f "ollama serve" > /dev/null; then
        echo "Starting Ollama..."
        nohup ollama serve > /tmp/ollama.log 2>&1 &
        sleep 3
    fi
    warmup-ollama
    echo "Ready for agent work! Use: npx claude-flow@v3alpha"
}

# ═══════════════════════════════════════════════════════════════
ENVCONFIG

    echo -e "${GREEN}✓ Environment configured${NC}"
fi

# Step 8: Create Claude settings
echo ""
echo -e "${CYAN}Step 8: Creating Claude settings...${NC}"
mkdir -p ~/.claude

if [ -f ~/.claude/settings.json ]; then
    echo -e "${YELLOW}~/.claude/settings.json exists, backing up...${NC}"
    cp ~/.claude/settings.json ~/.claude/settings.json.backup
fi

cat > ~/.claude/settings.json << 'SETTINGS'
{
  "env": {
    "ANTHROPIC_BASE_URL": "http://localhost:11434",
    "ANTHROPIC_AUTH_TOKEN": "ollama",
    "ANTHROPIC_API_KEY": ""
  },
  "model": "qwen3-coder",
  "theme": "dark",
  "hasCompletedOnboarding": true
}
SETTINGS

echo -e "${GREEN}✓ Claude settings created${NC}"

# Step 9: Warmup models
echo ""
echo -e "${CYAN}Step 9: Warming up models (first load takes longer)...${NC}"
curl -s http://localhost:11434/api/generate \
    -d '{"model":"qwen3-coder","prompt":"Hello, please respond with OK.","stream":false}' > /dev/null 2>&1 && \
    echo -e "${GREEN}✓ Model warmed up${NC}" || \
    echo -e "${YELLOW}⚠ Could not warmup model (may need to pull first)${NC}"

# Step 10: Test
echo ""
echo -e "${CYAN}Step 10: Testing setup...${NC}"

# Test Ollama API
if curl -s http://localhost:11434/api/tags > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Ollama API responding${NC}"
else
    echo -e "${RED}✗ Ollama API not responding${NC}"
fi

# List available models
echo ""
echo -e "${BLUE}Available Ollama models:${NC}"
ollama list 2>/dev/null || echo "  (none yet)"

# Final summary
echo ""
echo -e "${GREEN}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                    SETUP COMPLETE! 🎉                          ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${CYAN}To apply the new environment, run:${NC}"
echo -e "  ${YELLOW}source $SHELL_RC${NC}"
echo ""
echo -e "${CYAN}Quick commands:${NC}"
echo ""
echo -e "  ${BLUE}# Start agent session${NC}"
echo -e "  ${YELLOW}start-agents${NC}"
echo ""
echo -e "  ${BLUE}# Test Claude Code with local model${NC}"
echo -e "  ${YELLOW}claude --model qwen3-coder -p 'Hello, what model are you?'${NC}"
echo ""
echo -e "  ${BLUE}# Run claude-flow agent${NC}"
echo -e "  ${YELLOW}npx claude-flow@v3alpha --agent coder --task 'Create hello world'${NC}"
echo ""
echo -e "  ${BLUE}# Initialize claude-flow in a project${NC}"
echo -e "  ${YELLOW}cd your-project && npx claude-flow@v3alpha init${NC}"
echo ""
echo -e "  ${BLUE}# Start MCP server${NC}"
echo -e "  ${YELLOW}npx claude-flow@v3alpha mcp start${NC}"
echo ""
echo -e "${PURPLE}🦇 Happy night coding with free local inference!${NC}"
echo ""
