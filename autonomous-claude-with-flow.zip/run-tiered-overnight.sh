#!/bin/bash
#
# Night Architecture: Tiered Overnight Runner
#
# Intelligently uses your Claude Max subscription for main work,
# Ollama for parallel agents, and avoids API tokens entirely.
#
# This maximizes your $100/month Claude Max 2x plan!
#

set -euo pipefail

# Source the tiered inference system
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/tiered-inference.sh"

# ═══════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════

PROJECT_DIR="${PROJECT_DIR:-$(pwd)}"
STATE_DIR="$PROJECT_DIR/.night-arch"
LOG_DIR="$STATE_DIR/logs"

# Timing
MAX_HOURS="${MAX_HOURS:-8}"
MAX_ITERATIONS="${MAX_ITERATIONS:-50}"
PAUSE_BETWEEN_TASKS="${PAUSE_BETWEEN_TASKS:-10}"

# Strategy
USE_PARALLEL_AGENTS="${USE_PARALLEL_AGENTS:-true}"
PARALLEL_AGENT_COUNT="${PARALLEL_AGENT_COUNT:-3}"
EVOLUTION_FREQUENCY="${EVOLUTION_FREQUENCY:-5}"

# Calculate end time
START_TIME=$(date +%s)
END_TIME=$((START_TIME + MAX_HOURS * 3600))

# ═══════════════════════════════════════════════════════════════
# INITIALIZATION
# ═══════════════════════════════════════════════════════════════

init_night_arch() {
    mkdir -p "$STATE_DIR"/{tasks,completed,patterns,logs,checkpoints}
    touch "$STATE_DIR/tasks/pending.txt"
    touch "$STATE_DIR/tasks/failed.txt"
    
    # Initialize tracking
    if [ ! -f "$STATE_DIR/session.json" ]; then
        cat > "$STATE_DIR/session.json" << EOF
{
    "started_at": "$(date -Iseconds)",
    "iterations": 0,
    "tasks_completed": 0,
    "claude_max_calls": 0,
    "ollama_calls": 0,
    "api_calls": 0
}
EOF
    fi
}

log_night() {
    local message=$1
    local timestamp=$(date '+%H:%M:%S')
    echo -e "${CYAN}[$timestamp]${NC} $message"
    echo "[$timestamp] $message" >> "$LOG_DIR/overnight.log"
}

# ═══════════════════════════════════════════════════════════════
# AGENT CALLS (Using Tiered System)
# ═══════════════════════════════════════════════════════════════

# Main agent call - uses Claude Max (your subscription)
call_main_agent() {
    local agent_type=$1
    local prompt=$2
    local output_file=$3
    
    log_night "🎯 Main Agent ($agent_type) via Claude Max"
    
    # Use claude -p which goes through your subscription
    local full_prompt="You are a $agent_type agent. $prompt"
    infer "$full_prompt" "$output_file" "claude_max" "critical"
    
    # Update session tracking
    jq '.claude_max_calls += 1' "$STATE_DIR/session.json" > "$STATE_DIR/session.json.tmp"
    mv "$STATE_DIR/session.json.tmp" "$STATE_DIR/session.json"
}

# Parallel analysis - uses Ollama (free, preserves Max quota)
call_parallel_analysis() {
    local task=$1
    local output_dir=$2
    
    log_night "🔀 Parallel Analysis via Ollama (free)"
    
    run_parallel_agents "$task" "$PARALLEL_AGENT_COUNT" "$output_dir"
    
    # Update session tracking
    jq --argjson count "$PARALLEL_AGENT_COUNT" '.ollama_calls += $count' "$STATE_DIR/session.json" > "$STATE_DIR/session.json.tmp"
    mv "$STATE_DIR/session.json.tmp" "$STATE_DIR/session.json"
}

# ═══════════════════════════════════════════════════════════════
# TASK EXECUTION
# ═══════════════════════════════════════════════════════════════

execute_task() {
    local task=$1
    local task_id=$(echo "$task" | md5sum | cut -c1-8)
    local task_dir="$STATE_DIR/tasks/$task_id"
    
    mkdir -p "$task_dir"
    echo "$task" > "$task_dir/task.txt"
    
    log_night "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    log_night "📋 Task: ${task:0:60}..."
    log_night "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    local iteration=0
    local max_iterations=3
    local success=false
    
    while [ $iteration -lt $max_iterations ] && [ "$success" = false ]; do
        iteration=$((iteration + 1))
        log_night "Attempt $iteration/$max_iterations"
        
        # PHASE 1: Parallel exploration (Ollama - free)
        if [ "$USE_PARALLEL_AGENTS" = true ]; then
            log_night "Phase 1: Multi-perspective analysis..."
            call_parallel_analysis "Analyze approaches for: $task" "$task_dir/parallel_$iteration"
        fi
        
        # PHASE 2: Architecture (Claude Max - subscription)
        log_night "Phase 2: Architecture design..."
        call_main_agent "architect" \
            "Design a solution for: $task\n\nContext from parallel analysis: $(cat "$task_dir/parallel_$iteration/synthesis.json" 2>/dev/null || echo 'none')" \
            "$task_dir/architecture_$iteration.json"
        
        # PHASE 3: Implementation (Claude Max - subscription)
        log_night "Phase 3: Implementation..."
        local design=$(cat "$task_dir/architecture_$iteration.json" 2>/dev/null | head -c 2000)
        call_main_agent "coder" \
            "Implement this design:\n$design\n\nOriginal task: $task" \
            "$task_dir/implementation_$iteration.json"
        
        # PHASE 4: Review (Claude Max - subscription)
        log_night "Phase 4: Review..."
        local code=$(cat "$task_dir/implementation_$iteration.json" 2>/dev/null | head -c 2000)
        call_main_agent "reviewer" \
            "Review this implementation for correctness, security, and quality:\n$code\n\nProvide verdict: APPROVE, REVISE, or REJECT" \
            "$task_dir/review_$iteration.json"
        
        # Check verdict
        local verdict=$(cat "$task_dir/review_$iteration.json" 2>/dev/null | grep -oE '(APPROVE|REVISE|REJECT)' | head -1 || echo "UNKNOWN")
        
        if [ "$verdict" = "APPROVE" ]; then
            success=true
            log_night "✅ Task approved!"
        else
            log_night "⚠️  Verdict: $verdict - will retry"
        fi
    done
    
    if [ "$success" = true ]; then
        mv "$task_dir" "$STATE_DIR/completed/$task_id"
        jq '.tasks_completed += 1' "$STATE_DIR/session.json" > "$STATE_DIR/session.json.tmp"
        mv "$STATE_DIR/session.json.tmp" "$STATE_DIR/session.json"
        return 0
    else
        echo "$task" >> "$STATE_DIR/tasks/failed.txt"
        return 1
    fi
}

# ═══════════════════════════════════════════════════════════════
# MAIN LOOP
# ═══════════════════════════════════════════════════════════════

should_continue() {
    local iteration=$1
    local current_time=$(date +%s)
    
    [ $iteration -lt $MAX_ITERATIONS ] && [ $current_time -lt $END_TIME ]
}

show_banner() {
    clear
    echo ""
    echo -e "${PURPLE}╔════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${PURPLE}║                                                                ║${NC}"
    echo -e "${PURPLE}║   🦇  NIGHT ARCHITECTURE - TIERED OVERNIGHT MODE  🦇          ║${NC}"
    echo -e "${PURPLE}║                                                                ║${NC}"
    echo -e "${PURPLE}║   Maximizing your Claude Max subscription                      ║${NC}"
    echo -e "${PURPLE}║   + Free parallel work via Ollama                              ║${NC}"
    echo -e "${PURPLE}║   = Zero API token burn! 💰                                    ║${NC}"
    echo -e "${PURPLE}║                                                                ║${NC}"
    echo -e "${PURPLE}╚════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "  Max Iterations: ${CYAN}$MAX_ITERATIONS${NC}"
    echo -e "  Max Runtime:    ${CYAN}$MAX_HOURS hours${NC}"
    echo -e "  Parallel Agents: ${CYAN}$PARALLEL_AGENT_COUNT (via Ollama)${NC}"
    echo -e "  End Time:       ${CYAN}$(date -d @$END_TIME '+%Y-%m-%d %H:%M:%S')${NC}"
    echo ""
}

show_progress() {
    local iteration=$1
    local elapsed=$(($(date +%s) - START_TIME))
    local remaining=$((END_TIME - $(date +%s)))
    
    local max_calls=$(jq -r '.claude_max_calls' "$STATE_DIR/session.json")
    local ollama_calls=$(jq -r '.ollama_calls' "$STATE_DIR/session.json")
    local completed=$(jq -r '.tasks_completed' "$STATE_DIR/session.json")
    
    echo ""
    echo -e "${CYAN}┌─────────────────────────────────────────────────────┐${NC}"
    echo -e "${CYAN}│ Progress: $iteration/$MAX_ITERATIONS iterations                        │${NC}"
    echo -e "${CYAN}│ Time: $(printf '%02d:%02d' $((elapsed/3600)) $((elapsed%3600/60))) elapsed / $(printf '%02d:%02d' $((remaining/3600)) $((remaining%3600/60))) remaining     │${NC}"
    echo -e "${CYAN}│ Completed: $completed tasks                                │${NC}"
    echo -e "${CYAN}│ Claude Max calls: $max_calls (subscription)              │${NC}"
    echo -e "${CYAN}│ Ollama calls: $ollama_calls (free)                        │${NC}"
    echo -e "${CYAN}│ API calls: 0 (avoided! 🎉)                          │${NC}"
    echo -e "${CYAN}└─────────────────────────────────────────────────────┘${NC}"
    echo ""
}

create_morning_briefing() {
    local briefing="$STATE_DIR/morning_briefing_$(date +%Y%m%d).md"
    
    local max_calls=$(jq -r '.claude_max_calls' "$STATE_DIR/session.json")
    local ollama_calls=$(jq -r '.ollama_calls' "$STATE_DIR/session.json")
    local completed=$(jq -r '.tasks_completed' "$STATE_DIR/session.json")
    local failed=$(wc -l < "$STATE_DIR/tasks/failed.txt" 2>/dev/null || echo "0")
    
    cat > "$briefing" << EOF
# 🦇 Night Architecture - Morning Briefing

**Generated:** $(date '+%Y-%m-%d %H:%M:%S')

## Summary

| Metric | Count |
|--------|-------|
| Tasks Completed | $completed |
| Tasks Failed | $failed |
| Claude Max Calls | $max_calls |
| Ollama Calls | $ollama_calls |
| API Calls | 0 |

## Cost Analysis

- **Claude Max Calls**: $max_calls (covered by subscription ✅)
- **Ollama Calls**: $ollama_calls (free local inference ✅)
- **API Tokens Used**: 0 (avoided! 🎉)

**Estimated Savings**: If these $((max_calls + ollama_calls)) calls went to API instead:
- ~$((($max_calls + $ollama_calls) * 3 / 100)) estimated (at ~\$3/1M tokens)

## Your Claude Max Subscription Status

You've used approximately $max_calls of your subscription quota overnight.
This is well within your Claude Max 2x plan limits!

---
*Zero API burn achieved* 💰
EOF

    echo "$briefing"
}

main() {
    show_banner
    init_night_arch
    
    # Check prerequisites
    if ! command -v claude &> /dev/null; then
        log_night "❌ Claude Code not found. Install it first!"
        exit 1
    fi
    
    if ! check_ollama_available; then
        log_night "⚠️  Ollama not running. Starting..."
        export OLLAMA_HOST=0.0.0.0:11434
        nohup ollama serve > /tmp/ollama.log 2>&1 &
        sleep 3
    fi
    
    # Warmup Ollama
    log_night "🔥 Warming up Ollama..."
    curl -s "http://$OLLAMA_HOST:$OLLAMA_PORT/api/generate" \
        -d '{"model":"'"$OLLAMA_MODEL"'","prompt":"warmup","stream":false}' > /dev/null 2>&1 || true
    
    log_night "🚀 Starting overnight loop..."
    
    local iteration=0
    
    while should_continue $iteration; do
        iteration=$((iteration + 1))
        
        show_progress $iteration
        
        # Get next task
        local task=""
        if [ -f "$STATE_DIR/tasks/pending.txt" ] && [ -s "$STATE_DIR/tasks/pending.txt" ]; then
            task=$(head -n 1 "$STATE_DIR/tasks/pending.txt")
            sed -i '1d' "$STATE_DIR/tasks/pending.txt"
        else
            # No pending tasks - could generate or wait
            log_night "📭 No pending tasks. Add tasks to $STATE_DIR/tasks/pending.txt"
            log_night "    or pass tasks via command line"
            break
        fi
        
        if [ -n "$task" ]; then
            execute_task "$task" || true
        fi
        
        # Update session
        jq '.iterations += 1' "$STATE_DIR/session.json" > "$STATE_DIR/session.json.tmp"
        mv "$STATE_DIR/session.json.tmp" "$STATE_DIR/session.json"
        
        # Pause between tasks
        if should_continue $((iteration + 1)); then
            log_night "💤 Pausing ${PAUSE_BETWEEN_TASKS}s..."
            sleep "$PAUSE_BETWEEN_TASKS"
        fi
    done
    
    # Generate morning briefing
    local briefing=$(create_morning_briefing)
    
    echo ""
    echo -e "${GREEN}╔════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║              OVERNIGHT SESSION COMPLETE! 🎉                    ║${NC}"
    echo -e "${GREEN}╚════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo "📋 Morning briefing: $briefing"
    echo ""
    
    # Show final status
    show_status
}

# Handle arguments
case "${1:-}" in
    --add-task)
        echo "${2:-}" >> "$STATE_DIR/tasks/pending.txt"
        echo "Task added to queue"
        ;;
    --status)
        show_status
        ;;
    --help)
        echo "Usage: $0 [options]"
        echo ""
        echo "Options:"
        echo "  --add-task \"task\"   Add a task to the queue"
        echo "  --status            Show inference tier status"
        echo "  --help              Show this help"
        echo ""
        echo "Environment:"
        echo "  MAX_HOURS           Max runtime in hours (default: 8)"
        echo "  MAX_ITERATIONS      Max task iterations (default: 50)"
        echo "  USE_PARALLEL_AGENTS Use Ollama for parallel analysis (default: true)"
        ;;
    *)
        # If argument provided, treat as a single task
        if [ -n "${1:-}" ]; then
            mkdir -p "$STATE_DIR/tasks"
            echo "$1" >> "$STATE_DIR/tasks/pending.txt"
        fi
        main
        ;;
esac
