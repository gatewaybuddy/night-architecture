# Night Architecture: Tiered Inference System

**Maximize your Claude Max subscription. Use local inference for parallel work. Avoid API tokens entirely.**

## The Problem

You're paying $100/month for Claude Max 2x, but if you use `ANTHROPIC_API_KEY`, you're burning expensive API tokens instead of your subscription! This system fixes that.

## The Solution: 3-Tier Priority System

```
┌─────────────────────────────────────────────────────────────────┐
│                    INFERENCE PRIORITY                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   TIER 1: Claude Max (Primary)                                  │
│   ┌─────────────────────────────────────────────┐               │
│   │  • Uses: claude -p (headless CLI)           │               │
│   │  • Cost: $0 (covered by subscription)       │               │
│   │  • Quality: Best (Claude Sonnet/Opus)       │               │
│   │  • Use for: Main agent work, synthesis      │               │
│   └─────────────────────────────────────────────┘               │
│                         ↓ (if rate limited)                     │
│   TIER 2: Ollama Local (Secondary)                              │
│   ┌─────────────────────────────────────────────┐               │
│   │  • Uses: Local qwen3-coder on your GPU      │               │
│   │  • Cost: $0 (electricity only)              │               │
│   │  • Quality: Good (85% of Claude)            │               │
│   │  • Use for: Parallel agents, bulk analysis  │               │
│   └─────────────────────────────────────────────┘               │
│                         ↓ (last resort only)                    │
│   TIER 3: Anthropic API (Avoid!)                                │
│   ┌─────────────────────────────────────────────┐               │
│   │  • Uses: Direct API with ANTHROPIC_API_KEY  │               │
│   │  • Cost: ~$3-15 per 1M tokens               │               │
│   │  • Quality: Best                            │               │
│   │  • Use for: NEVER (if possible)             │               │
│   └─────────────────────────────────────────────┘               │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## How It Works

### Main Work → Claude Max (Your Subscription)

The `claude -p` command uses your Claude Max subscription, NOT API tokens:

```bash
# This uses your subscription (free with Max!)
claude -p "Design an authentication system" --output-format json
```

### Parallel Agents → Ollama (Free)

When running multiple agents in parallel (like the Devil's Advocate pattern), we use Ollama to avoid eating into your Max quota:

```bash
# These 3 parallel agents use Ollama (free!)
Agent 1 (Architect)  → Ollama/qwen3-coder → Free
Agent 2 (Critic)     → Ollama/qwen3-coder → Free  
Agent 3 (Alternative)→ Ollama/qwen3-coder → Free

# Then synthesize with Claude Max (subscription)
Synthesis → claude -p → Covered by Max
```

### API Tokens → Last Resort

The system will ONLY use API tokens if:
1. Claude Max is unavailable (rate limited)
2. Ollama is offline
3. You explicitly force it

## Quick Start

```bash
# 1. Make sure Ollama is running with qwen3-coder
ollama serve &
ollama pull qwen3-coder

# 2. Run the setup (optional, configures environment)
chmod +x *.sh
./tiered-inference.sh status

# 3. Add tasks and run overnight
./run-tiered-overnight.sh --add-task "Build a REST API for user management"
./run-tiered-overnight.sh --add-task "Create comprehensive tests"
./run-tiered-overnight.sh --add-task "Add authentication middleware"

# 4. Let it run overnight
./run-tiered-overnight.sh
```

## Usage Examples

### Single Inference Call

```bash
# Auto-route (prefers Claude Max, falls back to Ollama)
./tiered-inference.sh infer "Design a caching system" output.json auto general

# Force Claude Max (uses subscription)
./tiered-inference.sh infer "Critical architecture decision" output.json claude_max critical

# Force Ollama (free, good for parallel work)
./tiered-inference.sh infer "Quick analysis" output.json ollama parallel
```

### Check Status

```bash
./tiered-inference.sh status
```

Output:
```
╔════════════════════════════════════════════════════════════════╗
║           INFERENCE TIER STATUS                                ║
╚════════════════════════════════════════════════════════════════╝

Tier 1: Claude Max (Subscription)
  Status: Available
  Total Requests: 45
  This Hour: 12 / 200

Tier 2: Ollama Local (Free)
  Status: Available
  Model: qwen3-coder
  Total Requests: 128
  Failures: 2

Tier 3: Anthropic API (Paid)
  Status: Not Configured (good!)
  Total Requests: 0
  Total Tokens: 0
```

### Parallel Agents (Uses Ollama)

```bash
# Spawn 5 parallel agents analyzing from different perspectives
./tiered-inference.sh parallel "Evaluate microservices vs monolith" 5 /tmp/analysis

# Results:
# - 5 Ollama calls (free!)
# - 1 Claude Max call for synthesis (subscription)
```

## Configuration

### Environment Variables

```bash
# Ollama settings
export OLLAMA_HOST=localhost
export OLLAMA_PORT=11434
export OLLAMA_MODEL=qwen3-coder

# Rate limiting for Claude Max (avoid hitting subscription limits)
# These are conservative defaults - adjust based on your plan
MAX_REQUESTS_PER_MINUTE=10
MAX_REQUESTS_PER_HOUR=200

# DO NOT SET THIS unless you really need API fallback
# export ANTHROPIC_API_KEY=sk-ant-...  # Leave unset!
```

### Overnight Settings

```bash
# Run for 8 hours max
MAX_HOURS=8

# Process up to 50 tasks
MAX_ITERATIONS=50

# Use 3 parallel agents per task (via Ollama)
PARALLEL_AGENT_COUNT=3

# Wait 10 seconds between tasks (be nice to rate limits)
PAUSE_BETWEEN_TASKS=10
```

## Cost Comparison: Old vs New

### Old Approach (API Tokens)

```
50 tasks × 4 agent calls × ~2000 tokens = 400,000 tokens
Cost: ~$1.20 (Sonnet) to ~$6 (Opus) per night
Monthly: $36-180 just for overnight runs
```

### New Approach (Tiered)

```
50 tasks:
  - Main work: 200 Claude Max calls (subscription - $0)
  - Parallel: 150 Ollama calls (free - $0)
  - API: 0 calls ($0)

Total cost: $0 (covered by your Max subscription!)
```

## Tips for Maximum Efficiency

### 1. Frontload Parallel Analysis

```bash
# Do exploration with Ollama (free)
# Then synthesize with Claude Max (subscription)
```

### 2. Batch Similar Tasks

```bash
# Group related tasks to reuse context
./run-tiered-overnight.sh --add-task "Auth: Design user model"
./run-tiered-overnight.sh --add-task "Auth: Implement login"
./run-tiered-overnight.sh --add-task "Auth: Add JWT tokens"
```

### 3. Monitor Your Quota

```bash
# Check status periodically
./tiered-inference.sh status

# The system auto-throttles when approaching limits
```

### 4. Use Ollama for Experimentation

```bash
# Quick iterations during development - use Ollama
./tiered-inference.sh infer "Try approach A" out.json ollama
./tiered-inference.sh infer "Try approach B" out.json ollama
./tiered-inference.sh infer "Try approach C" out.json ollama

# Final decision - use Claude Max for quality
./tiered-inference.sh infer "Choose best approach from A,B,C" out.json claude_max
```

## File Structure

```
night-architecture-tiered/
├── tiered-inference.sh       # Core inference router
├── run-tiered-overnight.sh   # Overnight orchestrator
├── README.md                 # This file
└── .night-arch/              # State directory (created at runtime)
    ├── session.json          # Current session stats
    ├── rate_tracking.json    # Rate limit tracking
    ├── tasks/
    │   ├── pending.txt       # Tasks to process
    │   └── failed.txt        # Failed tasks
    ├── completed/            # Completed task artifacts
    └── logs/                 # Logs
```

## Troubleshooting

### "Claude Max rate limited"

The system automatically falls back to Ollama. To increase limits:

```bash
# In tiered-inference.sh
MAX_REQUESTS_PER_MINUTE=15  # Increase cautiously
MAX_REQUESTS_PER_HOUR=300
```

### "Ollama not responding"

```bash
# Start Ollama
export OLLAMA_HOST=0.0.0.0:11434
ollama serve &

# Pull the model
ollama pull qwen3-coder

# Warmup
curl http://localhost:11434/api/generate -d '{"model":"qwen3-coder","prompt":"hi"}'
```

### "Getting API charges anyway"

Make sure you DON'T have `ANTHROPIC_API_KEY` set:

```bash
# Check
echo $ANTHROPIC_API_KEY

# Unset if present
unset ANTHROPIC_API_KEY
```

The `claude -p` command should use your subscription automatically when no API key is set.

---

## Summary

| Tier | Method | Cost | Use For |
|------|--------|------|---------|
| 1 | `claude -p` | $0 (Max subscription) | Main agent work |
| 2 | Ollama API | $0 (local) | Parallel agents, bulk work |
| 3 | Anthropic API | $$$ | AVOID |

**Result**: Full multi-agent overnight automation using only your existing Claude Max subscription + free local inference. Zero API burn! 🦇
