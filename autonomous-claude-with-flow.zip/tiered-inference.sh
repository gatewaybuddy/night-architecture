#!/bin/bash
#
# Night Architecture: Tiered Inference Router
# 
# Priority routing to maximize value from Claude Max subscription:
#   1. Claude Max (via `claude -p`) - Your subscription, already paid
#   2. Local Ollama - Free, unlimited, good for parallel work
#   3. API tokens - Only when explicitly needed (expensive)
#
# This avoids burning API tokens while leveraging your $100/month Max plan!
#

set -euo pipefail

# ═══════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════

# Inference tiers (in priority order)
TIER_1="claude_max"      # Primary: Your subscription via headless CLI
TIER_2="ollama_local"    # Secondary: Free local inference
TIER_3="anthropic_api"   # Tertiary: Direct API (expensive, avoid)

# Current tier to use
CURRENT_TIER="${INFERENCE_TIER:-$TIER_1}"

# Ollama configuration
OLLAMA_HOST="${OLLAMA_HOST:-localhost}"
OLLAMA_PORT="${OLLAMA_PORT:-11434}"
OLLAMA_MODEL="${OLLAMA_MODEL:-qwen3-coder}"

# Rate limiting for Claude Max (avoid hitting limits)
MAX_REQUESTS_PER_MINUTE=10
MAX_REQUESTS_PER_HOUR=200
REQUEST_DELAY_SECONDS=6  # Space out requests

# Tracking files
STATE_DIR="${STATE_DIR:-$HOME/.night-architecture}"
RATE_FILE="$STATE_DIR/rate_tracking.json"
LOG_FILE="$STATE_DIR/inference.log"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

# ═══════════════════════════════════════════════════════════════
# INITIALIZATION
# ═══════════════════════════════════════════════════════════════

init_state() {
    mkdir -p "$STATE_DIR"
    
    if [ ! -f "$RATE_FILE" ]; then
        cat > "$RATE_FILE" << 'EOF'
{
    "claude_max": {
        "requests_this_minute": 0,
        "requests_this_hour": 0,
        "minute_start": 0,
        "hour_start": 0,
        "total_requests": 0
    },
    "ollama_local": {
        "total_requests": 0,
        "failures": 0
    },
    "anthropic_api": {
        "total_requests": 0,
        "total_tokens": 0
    }
}
EOF
    fi
}

log() {
    local level=$1
    local message=$2
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$timestamp] [$level] $message" >> "$LOG_FILE"
    
    case $level in
        INFO)    echo -e "${BLUE}ℹ${NC} $message" ;;
        SUCCESS) echo -e "${GREEN}✓${NC} $message" ;;
        WARN)    echo -e "${YELLOW}⚠${NC} $message" ;;
        ERROR)   echo -e "${RED}✗${NC} $message" ;;
        TIER)    echo -e "${PURPLE}◆${NC} $message" ;;
    esac
}

# ═══════════════════════════════════════════════════════════════
# TIER 1: CLAUDE MAX (via headless CLI)
# ═══════════════════════════════════════════════════════════════

check_claude_max_available() {
    # Check if claude CLI is available
    if ! command -v claude &> /dev/null; then
        return 1
    fi
    
    # Check rate limits
    local now=$(date +%s)
    local minute_start=$(jq -r '.claude_max.minute_start' "$RATE_FILE")
    local hour_start=$(jq -r '.claude_max.hour_start' "$RATE_FILE")
    local requests_minute=$(jq -r '.claude_max.requests_this_minute' "$RATE_FILE")
    local requests_hour=$(jq -r '.claude_max.requests_this_hour' "$RATE_FILE")
    
    # Reset counters if time windows passed
    if [ $((now - minute_start)) -ge 60 ]; then
        requests_minute=0
    fi
    if [ $((now - hour_start)) -ge 3600 ]; then
        requests_hour=0
    fi
    
    # Check if under limits
    if [ "$requests_minute" -ge "$MAX_REQUESTS_PER_MINUTE" ]; then
        log WARN "Claude Max: minute rate limit reached ($requests_minute/$MAX_REQUESTS_PER_MINUTE)"
        return 1
    fi
    if [ "$requests_hour" -ge "$MAX_REQUESTS_PER_HOUR" ]; then
        log WARN "Claude Max: hour rate limit reached ($requests_hour/$MAX_REQUESTS_PER_HOUR)"
        return 1
    fi
    
    return 0
}

call_claude_max() {
    local prompt=$1
    local output_file=$2
    local model="${3:-claude-sonnet-4-5-20250929}"
    
    log TIER "Using Tier 1: Claude Max (your subscription)"
    
    # Update rate tracking
    local now=$(date +%s)
    local temp_file=$(mktemp)
    
    jq --argjson now "$now" '
        .claude_max.requests_this_minute += 1 |
        .claude_max.requests_this_hour += 1 |
        .claude_max.total_requests += 1 |
        if (.claude_max.minute_start == 0 or ($now - .claude_max.minute_start) >= 60) 
            then .claude_max.minute_start = $now | .claude_max.requests_this_minute = 1 
            else . end |
        if (.claude_max.hour_start == 0 or ($now - .claude_max.hour_start) >= 3600) 
            then .claude_max.hour_start = $now | .claude_max.requests_this_hour = 1 
            else . end
    ' "$RATE_FILE" > "$temp_file" && mv "$temp_file" "$RATE_FILE"
    
    # Call Claude via headless CLI (uses your subscription!)
    if claude -p "$prompt" --output-format json > "$output_file" 2>> "$LOG_FILE"; then
        log SUCCESS "Claude Max call successful"
        
        # Respect rate limiting with delay
        sleep "$REQUEST_DELAY_SECONDS"
        return 0
    else
        log ERROR "Claude Max call failed"
        return 1
    fi
}

# ═══════════════════════════════════════════════════════════════
# TIER 2: OLLAMA LOCAL (free, unlimited)
# ═══════════════════════════════════════════════════════════════

check_ollama_available() {
    curl -s "http://$OLLAMA_HOST:$OLLAMA_PORT/api/tags" > /dev/null 2>&1
}

call_ollama() {
    local prompt=$1
    local output_file=$2
    local model="${3:-$OLLAMA_MODEL}"
    
    log TIER "Using Tier 2: Ollama Local (free)"
    
    # Update tracking
    local temp_file=$(mktemp)
    jq '.ollama_local.total_requests += 1' "$RATE_FILE" > "$temp_file" && mv "$temp_file" "$RATE_FILE"
    
    # Call Ollama
    local response=$(curl -s "http://$OLLAMA_HOST:$OLLAMA_PORT/api/generate" \
        -d "{\"model\":\"$model\",\"prompt\":\"$prompt\",\"stream\":false}" 2>> "$LOG_FILE")
    
    if [ $? -eq 0 ] && [ -n "$response" ]; then
        echo "$response" | jq -r '.response // .message // .' > "$output_file"
        log SUCCESS "Ollama call successful"
        return 0
    else
        log ERROR "Ollama call failed"
        # Update failure count
        jq '.ollama_local.failures += 1' "$RATE_FILE" > "$temp_file" && mv "$temp_file" "$RATE_FILE"
        return 1
    fi
}

# ═══════════════════════════════════════════════════════════════
# TIER 3: ANTHROPIC API (expensive, use sparingly)
# ═══════════════════════════════════════════════════════════════

check_api_available() {
    [ -n "${ANTHROPIC_API_KEY:-}" ]
}

call_anthropic_api() {
    local prompt=$1
    local output_file=$2
    local model="${3:-claude-sonnet-4-5-20250929}"
    
    log TIER "Using Tier 3: Anthropic API (COSTS MONEY!)"
    log WARN "API tokens being consumed - consider using Claude Max or Ollama instead"
    
    # Update tracking
    local temp_file=$(mktemp)
    jq '.anthropic_api.total_requests += 1' "$RATE_FILE" > "$temp_file" && mv "$temp_file" "$RATE_FILE"
    
    # Call API
    local response=$(curl -s https://api.anthropic.com/v1/messages \
        -H "Content-Type: application/json" \
        -H "x-api-key: $ANTHROPIC_API_KEY" \
        -H "anthropic-version: 2023-06-01" \
        -d "{
            \"model\": \"$model\",
            \"max_tokens\": 4096,
            \"messages\": [{\"role\": \"user\", \"content\": \"$prompt\"}]
        }" 2>> "$LOG_FILE")
    
    if [ $? -eq 0 ]; then
        echo "$response" | jq -r '.content[0].text // .' > "$output_file"
        
        # Track token usage
        local input_tokens=$(echo "$response" | jq -r '.usage.input_tokens // 0')
        local output_tokens=$(echo "$response" | jq -r '.usage.output_tokens // 0')
        local total_tokens=$((input_tokens + output_tokens))
        
        jq --argjson tokens "$total_tokens" '.anthropic_api.total_tokens += $tokens' "$RATE_FILE" > "$temp_file" && mv "$temp_file" "$RATE_FILE"
        
        log SUCCESS "API call successful ($total_tokens tokens used)"
        return 0
    else
        log ERROR "API call failed"
        return 1
    fi
}

# ═══════════════════════════════════════════════════════════════
# SMART ROUTER
# ═══════════════════════════════════════════════════════════════

# Main inference function - routes to best available tier
infer() {
    local prompt=$1
    local output_file=$2
    local preferred_tier="${3:-auto}"  # auto, claude_max, ollama, api
    local task_type="${4:-general}"    # general, parallel, critical
    
    init_state
    
    # Determine routing strategy
    case "$preferred_tier" in
        "claude_max")
            # Force Claude Max
            if check_claude_max_available; then
                call_claude_max "$prompt" "$output_file"
                return $?
            else
                log WARN "Claude Max requested but unavailable, falling back..."
            fi
            ;;
        "ollama")
            # Force Ollama
            if check_ollama_available; then
                call_ollama "$prompt" "$output_file"
                return $?
            else
                log WARN "Ollama requested but unavailable, falling back..."
            fi
            ;;
        "api")
            # Force API (why would you do this?)
            if check_api_available; then
                call_anthropic_api "$prompt" "$output_file"
                return $?
            else
                log ERROR "API requested but no ANTHROPIC_API_KEY set"
                return 1
            fi
            ;;
    esac
    
    # Auto routing based on task type and availability
    case "$task_type" in
        "parallel")
            # For parallel agents, prefer Ollama to avoid rate limits
            if check_ollama_available; then
                call_ollama "$prompt" "$output_file"
                return $?
            elif check_claude_max_available; then
                call_claude_max "$prompt" "$output_file"
                return $?
            fi
            ;;
        "critical")
            # For critical tasks, prefer Claude Max for quality
            if check_claude_max_available; then
                call_claude_max "$prompt" "$output_file"
                return $?
            elif check_api_available; then
                call_anthropic_api "$prompt" "$output_file"
                return $?
            fi
            ;;
        *)
            # Default: Try tiers in order
            if check_claude_max_available; then
                call_claude_max "$prompt" "$output_file"
                return $?
            elif check_ollama_available; then
                call_ollama "$prompt" "$output_file"
                return $?
            elif check_api_available; then
                call_anthropic_api "$prompt" "$output_file"
                return $?
            fi
            ;;
    esac
    
    log ERROR "No inference tier available!"
    return 1
}

# ═══════════════════════════════════════════════════════════════
# PARALLEL AGENT HELPER
# ═══════════════════════════════════════════════════════════════

# Run multiple agents in parallel using Ollama (to preserve Claude Max quota)
run_parallel_agents() {
    local task=$1
    local agent_count="${2:-3}"
    local output_dir="${3:-/tmp/parallel_agents}"
    
    mkdir -p "$output_dir"
    
    log INFO "Spawning $agent_count parallel agents via Ollama..."
    
    local pids=()
    
    for i in $(seq 1 $agent_count); do
        local agent_prompt="You are Agent $i. Analyze this task from your perspective: $task"
        local agent_output="$output_dir/agent_${i}.json"
        
        # Run in background, using Ollama to preserve Claude Max quota
        (infer "$agent_prompt" "$agent_output" "ollama" "parallel") &
        pids+=($!)
    done
    
    # Wait for all agents
    for pid in "${pids[@]}"; do
        wait $pid
    done
    
    log SUCCESS "All parallel agents complete"
    
    # Synthesize with Claude Max (the critical thinking part)
    log INFO "Synthesizing results with Claude Max..."
    
    local synthesis_prompt="Synthesize these agent perspectives into a final recommendation:\n\n"
    for i in $(seq 1 $agent_count); do
        local agent_output="$output_dir/agent_${i}.json"
        if [ -f "$agent_output" ]; then
            synthesis_prompt+="Agent $i: $(cat "$agent_output")\n\n"
        fi
    done
    
    infer "$synthesis_prompt" "$output_dir/synthesis.json" "claude_max" "critical"
}

# ═══════════════════════════════════════════════════════════════
# STATUS AND MONITORING
# ═══════════════════════════════════════════════════════════════

show_status() {
    init_state
    
    echo ""
    echo -e "${PURPLE}╔════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${PURPLE}║           INFERENCE TIER STATUS                                ║${NC}"
    echo -e "${PURPLE}╚════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    # Tier 1: Claude Max
    echo -e "${CYAN}Tier 1: Claude Max (Subscription)${NC}"
    if check_claude_max_available; then
        echo -e "  Status: ${GREEN}Available${NC}"
    else
        echo -e "  Status: ${YELLOW}Rate Limited${NC}"
    fi
    local max_requests=$(jq -r '.claude_max.total_requests' "$RATE_FILE")
    local max_hour=$(jq -r '.claude_max.requests_this_hour' "$RATE_FILE")
    echo "  Total Requests: $max_requests"
    echo "  This Hour: $max_hour / $MAX_REQUESTS_PER_HOUR"
    echo ""
    
    # Tier 2: Ollama
    echo -e "${CYAN}Tier 2: Ollama Local (Free)${NC}"
    if check_ollama_available; then
        echo -e "  Status: ${GREEN}Available${NC}"
        echo "  Model: $OLLAMA_MODEL"
    else
        echo -e "  Status: ${RED}Offline${NC}"
    fi
    local ollama_requests=$(jq -r '.ollama_local.total_requests' "$RATE_FILE")
    local ollama_failures=$(jq -r '.ollama_local.failures' "$RATE_FILE")
    echo "  Total Requests: $ollama_requests"
    echo "  Failures: $ollama_failures"
    echo ""
    
    # Tier 3: API
    echo -e "${CYAN}Tier 3: Anthropic API (Paid)${NC}"
    if check_api_available; then
        echo -e "  Status: ${YELLOW}Available (use sparingly!)${NC}"
    else
        echo -e "  Status: ${GREEN}Not Configured (good!)${NC}"
    fi
    local api_requests=$(jq -r '.anthropic_api.total_requests' "$RATE_FILE")
    local api_tokens=$(jq -r '.anthropic_api.total_tokens' "$RATE_FILE")
    echo "  Total Requests: $api_requests"
    echo "  Total Tokens: $api_tokens"
    echo ""
    
    # Cost estimate
    if [ "$api_tokens" -gt 0 ]; then
        # Rough estimate: $3 per 1M tokens for Sonnet
        local cost=$(echo "scale=4; $api_tokens * 0.000003" | bc)
        echo -e "${YELLOW}Estimated API Cost: \$$cost${NC}"
    fi
    
    echo ""
}

reset_tracking() {
    rm -f "$RATE_FILE"
    init_state
    log SUCCESS "Tracking reset"
}

# ═══════════════════════════════════════════════════════════════
# CLI INTERFACE
# ═══════════════════════════════════════════════════════════════

usage() {
    echo "Night Architecture: Tiered Inference Router"
    echo ""
    echo "Usage: $0 <command> [options]"
    echo ""
    echo "Commands:"
    echo "  infer <prompt> [output_file] [tier] [task_type]"
    echo "      Make an inference call"
    echo "      tier: auto, claude_max, ollama, api"
    echo "      task_type: general, parallel, critical"
    echo ""
    echo "  parallel <task> [agent_count] [output_dir]"
    echo "      Run parallel agents (uses Ollama to preserve Max quota)"
    echo ""
    echo "  status"
    echo "      Show inference tier status and usage"
    echo ""
    echo "  reset"
    echo "      Reset tracking counters"
    echo ""
    echo "Environment Variables:"
    echo "  INFERENCE_TIER      - Default tier (claude_max, ollama_local, anthropic_api)"
    echo "  OLLAMA_HOST         - Ollama host (default: localhost)"
    echo "  OLLAMA_PORT         - Ollama port (default: 11434)"
    echo "  OLLAMA_MODEL        - Ollama model (default: qwen3-coder)"
    echo "  ANTHROPIC_API_KEY   - API key (only needed for Tier 3)"
    echo ""
    echo "Strategy:"
    echo "  1. Use Claude Max (your subscription) for main agent work"
    echo "  2. Use Ollama for parallel agents to avoid rate limits"
    echo "  3. Avoid API tokens unless absolutely necessary"
}

# Main
case "${1:-}" in
    infer)
        infer "${2:-}" "${3:-/tmp/inference_output.json}" "${4:-auto}" "${5:-general}"
        ;;
    parallel)
        run_parallel_agents "${2:-}" "${3:-3}" "${4:-/tmp/parallel_agents}"
        ;;
    status)
        show_status
        ;;
    reset)
        reset_tracking
        ;;
    *)
        usage
        ;;
esac
