# Night Architecture: Frontier Recursive Multi-Agent System

A cutting-edge multi-agent orchestration system designed for Claude Code, featuring anti-groupthink mechanisms, mutual-oversight managers, and self-improving agent evolution.

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         NIGHT ARCHITECTURE SYSTEM                           │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────── OVERSIGHT LAYER ───────────────────┐                 │
│  │                                                        │                 │
│  │   ┌──────────────┐      ┌──────────────┐              │                 │
│  │   │   MANAGER A  │◄────►│   MANAGER B  │              │                 │
│  │   │ (Challenger) │      │  (Refiner)   │              │                 │
│  │   └──────┬───────┘      └──────┬───────┘              │                 │
│  │          │                     │                       │                 │
│  │          └────────┬────────────┘                       │                 │
│  │                   ▼                                    │                 │
│  │          ┌───────────────┐                             │                 │
│  │          │ DEVIL'S ADVOCATE │ ◄── Anti-Groupthink     │                 │
│  │          │  (No Veto, Voice) │                         │                 │
│  │          └────────┬──────────┘                         │                 │
│  └───────────────────┼────────────────────────────────────┘                 │
│                      ▼                                                      │
│  ┌─────────────────── EXECUTION LAYER ───────────────────┐                 │
│  │                                                        │                 │
│  │   ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐  │                 │
│  │   │ARCHITECT│  │ CODER   │  │ TESTER  │  │REVIEWER │  │                 │
│  │   │  Agent  │  │  Agent  │  │  Agent  │  │  Agent  │  │                 │
│  │   └────┬────┘  └────┬────┘  └────┬────┘  └────┬────┘  │                 │
│  │        └────────────┴────────────┴────────────┘       │                 │
│  │                           │                            │                 │
│  └───────────────────────────┼────────────────────────────┘                 │
│                              ▼                                              │
│  ┌─────────────────── LEARNING LAYER ────────────────────┐                 │
│  │                                                        │                 │
│  │   ┌────────────────────────────────────────────────┐  │                 │
│  │   │              EVOLUTION ENGINE                   │  │                 │
│  │   │  • Agent DNA (prompts, parameters)             │  │                 │
│  │   │  • Performance Metrics                         │  │                 │
│  │   │  • Mutation Strategy                           │  │                 │
│  │   │  • EWC++ (prevent forgetting)                  │  │                 │
│  │   └────────────────────────────────────────────────┘  │                 │
│  │                                                        │                 │
│  │   ┌────────────────────────────────────────────────┐  │                 │
│  │   │              PATTERN BANK                       │  │                 │
│  │   │  • Successful trajectories                     │  │                 │
│  │   │  • Failed approaches (anti-patterns)           │  │                 │
│  │   │  • Task-solution mappings                      │  │                 │
│  │   └────────────────────────────────────────────────┘  │                 │
│  └────────────────────────────────────────────────────────┘                 │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Key Innovations

### 1. Anti-Groupthink Devil's Advocate
- Has a **voice but not a veto** - can challenge but not block
- Automatically argues against majority consensus
- Uses Socratic questioning to expose weak reasoning
- Prevents premature convergence

### 2. Mutual-Oversight Managers
- **Manager A (Challenger)**: Reviews agent outputs for quality
- **Manager B (Refiner)**: Periodically updates agent configurations
- Managers also review **each other** for accountability
- Neither manager can override without justification

### 3. Self-Improving Agents
- Each agent has "DNA" (prompt templates, parameters, tools)
- Performance metrics tracked per task type
- Evolutionary mutations applied based on success/failure
- EWC++ prevents catastrophic forgetting of good behaviors

### 4. Recursive Refinement Loop
- Gödel Agent-style self-modification
- Agents can propose changes to their own prompts
- Changes validated by oversight layer before application
- Creates ever-improving capability

## Installation

```bash
# Clone and setup
git clone <this-repo>
cd night-architecture-agents

# Initialize
./setup.sh

# Or manual setup
npm install
chmod +x *.sh
```

## Usage

### Run the Full System
```bash
./run-night-architecture.sh "Build a REST API for user authentication"
```

### Run Individual Components
```bash
# Just the execution loop
./agents/execution-loop.sh "task description"

# Just the oversight check
./agents/oversight-check.sh

# Just evolution/learning
./agents/evolution-cycle.sh
```

### Overnight Mode
```bash
# Run for 8 hours with safety caps
./run-overnight.sh --max-iterations 50 --max-hours 8

# Resume from checkpoint
./run-overnight.sh --resume
```

## Configuration

Edit `config/agents.json` to customize:
- Agent prompts and parameters
- Manager review criteria
- Evolution rates and mutation strategies
- Anti-groupthink thresholds

## File Structure

```
night-architecture-agents/
├── README.md
├── config/
│   ├── agents.json           # Agent DNA definitions
│   ├── managers.json         # Oversight configuration
│   └── evolution.json        # Learning parameters
├── agents/
│   ├── architect.sh          # Architecture agent
│   ├── coder.sh             # Implementation agent
│   ├── tester.sh            # Testing agent
│   ├── reviewer.sh          # Code review agent
│   └── devils-advocate.sh   # Anti-groupthink agent
├── managers/
│   ├── challenger.sh        # Manager A
│   └── refiner.sh           # Manager B
├── learning/
│   ├── evolution-engine.sh  # Agent evolution
│   └── pattern-bank.sh      # Pattern storage
├── state/
│   ├── tasks/               # Current tasks
│   ├── completed/           # Finished work
│   ├── patterns/            # Learned patterns
│   └── dna/                 # Agent configurations
├── run-night-architecture.sh
├── run-overnight.sh
└── setup.sh
```

## Research Foundations

This system synthesizes concepts from:

1. **Multi-Agent Reflexion (MAR)** - Verbal reinforcement learning with diverse critic personas
2. **Gödel Agent** - Self-referential recursive improvement
3. **Devil's Advocate Systems** - Anti-groupthink mechanisms from group decision research
4. **EWC++** - Elastic Weight Consolidation to prevent forgetting
5. **SONA** - Self-Optimizing Neural Architecture (<0.05ms adaptation)
6. **Multi-Agent Debate (MAD)** - Structured disagreement for better reasoning

## Safety Features

- **Git Safety Net**: Auto-commits on successful tasks
- **Checkpoint System**: Resume from any state
- **Token Budget**: Configurable spending limits
- **Human Checkpoints**: Pause points for review
- **Anti-Drift**: Hierarchical topology prevents goal drift
- **Retry Limits**: Tasks fail after N attempts, flagged for human review

## Performance Targets

| Metric | Target |
|--------|--------|
| Task completion rate | >85% |
| Anti-drift effectiveness | >90% |
| Learning improvement/cycle | 2-5% |
| Overnight success rate | >70% |
| Human intervention rate | <15% |
