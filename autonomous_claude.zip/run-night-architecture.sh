#!/bin/bash
#
# Night Architecture: Frontier Recursive Multi-Agent System
# Main Orchestration Script
#
# Usage: ./run-night-architecture.sh "Your task description"
#

set -euo pipefail

# Configuration
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STATE_DIR="$PROJECT_DIR/state"
CONFIG_DIR="$PROJECT_DIR/config"
LOG_DIR="$STATE_DIR/logs"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Initialize state directories
init_state() {
    mkdir -p "$STATE_DIR"/{tasks,completed,patterns,dna,shared,checkpoints}
    mkdir -p "$LOG_DIR"
    
    # Initialize shared context
    if [ ! -f "$STATE_DIR/shared/context.json" ]; then
        echo '{"iteration": 0, "patterns_learned": 0, "agents_evolved": 0}' > "$STATE_DIR/shared/context.json"
    fi
    
    # Initialize metrics
    if [ ! -f "$STATE_DIR/shared/metrics.json" ]; then
        echo '{"tasks_completed": 0, "success_rate": 0, "total_tokens": 0}' > "$STATE_DIR/shared/metrics.json"
    fi
}

# Logging
log() {
    local level=$1
    local message=$2
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$timestamp] [$level] $message" >> "$LOG_DIR/main.log"
    
    case $level in
        INFO)  echo -e "${BLUE}ℹ${NC} $message" ;;
        SUCCESS) echo -e "${GREEN}✓${NC} $message" ;;
        WARN)  echo -e "${YELLOW}⚠${NC} $message" ;;
        ERROR) echo -e "${RED}✗${NC} $message" ;;
        DEVIL) echo -e "${PURPLE}👿${NC} $message" ;;
        EVOLVE) echo -e "${CYAN}🧬${NC} $message" ;;
    esac
}

# Call Claude agent with prompt
call_agent() {
    local agent_name=$1
    local prompt=$2
    local output_file=$3
    
    # Get agent config
    local agent_config=$(jq -r ".agents.$agent_name" "$CONFIG_DIR/agents.json")
    local temperature=$(echo "$agent_config" | jq -r '.parameters.temperature')
    local max_tokens=$(echo "$agent_config" | jq -r '.parameters.max_tokens')
    
    log INFO "Calling $agent_name agent..."
    
    # Use Claude Code's headless mode
    claude -p "$prompt" --output-format json > "$output_file" 2>> "$LOG_DIR/${agent_name}.log"
    
    return $?
}

# Run Devil's Advocate check
run_devils_advocate() {
    local consensus=$1
    local arguments=$2
    local output_file="$STATE_DIR/tasks/devils_advocate_${TIMESTAMP}.json"
    
    log DEVIL "Devil's Advocate reviewing consensus..."
    
    local prompt=$(jq -r '.agents.devils_advocate.prompt_template' "$CONFIG_DIR/agents.json")
    prompt="${prompt//\{\{CONSENSUS\}\}/$consensus}"
    prompt="${prompt//\{\{ARGUMENTS\}\}/$arguments}"
    
    call_agent "devils_advocate" "$prompt" "$output_file"
    
    # Parse the response
    local recommendation=$(jq -r '.final_recommendation' "$output_file" 2>/dev/null || echo "UNKNOWN")
    local challenges=$(jq -r '.challenges | length' "$output_file" 2>/dev/null || echo "0")
    
    log DEVIL "Raised $challenges challenges. Recommendation: $recommendation"
    
    echo "$output_file"
}

# Run Manager A (Challenger) review
run_challenger_review() {
    local task=$1
    local outputs=$2
    local concerns=$3
    local output_file="$STATE_DIR/tasks/challenger_${TIMESTAMP}.json"
    
    log INFO "Manager A (Challenger) reviewing..."
    
    local prompt=$(jq -r '.managers.challenger.prompt_template' "$CONFIG_DIR/managers.json")
    prompt="${prompt//\{\{TASK\}\}/$task}"
    prompt="${prompt//\{\{OUTPUTS\}\}/$outputs}"
    prompt="${prompt//\{\{CONCERNS\}\}/$concerns}"
    
    call_agent "challenger" "$prompt" "$output_file"
    
    local verdict=$(jq -r '.verdict' "$output_file" 2>/dev/null || echo "UNKNOWN")
    local quality=$(jq -r '.quality_score' "$output_file" 2>/dev/null || echo "0")
    
    log INFO "Challenger verdict: $verdict (Quality: $quality/10)"
    
    echo "$output_file"
}

# Run Manager B (Refiner) evolution check
run_refiner_check() {
    local agent_name=$1
    local performance_data=$2
    local output_file="$STATE_DIR/dna/${agent_name}_evolution_${TIMESTAMP}.json"
    
    log EVOLVE "Manager B (Refiner) analyzing $agent_name evolution..."
    
    local agent_dna=$(jq -r ".agents.$agent_name" "$CONFIG_DIR/agents.json")
    local prompt=$(jq -r '.managers.refiner.prompt_template' "$CONFIG_DIR/managers.json")
    prompt="${prompt//\{\{AGENT_NAME\}\}/$agent_name}"
    prompt="${prompt//\{\{AGENT_DNA\}\}/$agent_dna}"
    prompt="${prompt//\{\{PERFORMANCE_DATA\}\}/$performance_data}"
    
    call_agent "refiner" "$prompt" "$output_file"
    
    local mutations=$(jq -r '.mutations | length' "$output_file" 2>/dev/null || echo "0")
    local expected=$(jq -r '.expected_improvement' "$output_file" 2>/dev/null || echo "0")
    
    log EVOLVE "Proposed $mutations mutations for $agent_name (Expected improvement: $expected%)"
    
    echo "$output_file"
}

# Apply approved mutations
apply_mutations() {
    local evolution_file=$1
    local agent_name=$2
    
    log EVOLVE "Applying approved mutations to $agent_name..."
    
    # Create backup
    cp "$CONFIG_DIR/agents.json" "$STATE_DIR/dna/agents_backup_${TIMESTAMP}.json"
    
    # Read mutations
    local mutations=$(jq -r '.mutations' "$evolution_file")
    
    # For each mutation, apply if confidence > 0.7
    echo "$mutations" | jq -c '.[] | select(.confidence > 0.7)' | while read mutation; do
        local target=$(echo "$mutation" | jq -r '.target')
        local proposed=$(echo "$mutation" | jq -r '.proposed')
        log EVOLVE "  Applying: $target -> $proposed"
        
        # Apply to agent config (simplified - in production use jq to modify)
        # This is a placeholder - real implementation would modify the JSON properly
    done
    
    log SUCCESS "Mutations applied. Backup at: agents_backup_${TIMESTAMP}.json"
}

# Main execution loop for a single task
execute_task() {
    local task=$1
    local iteration=0
    local max_iterations=5
    local success=false
    
    log INFO "Starting task: $task"
    echo "$task" > "$STATE_DIR/tasks/current_task.txt"
    
    # Create task tracking file
    local task_id=$(echo "$task" | md5sum | cut -c1-8)
    local task_file="$STATE_DIR/tasks/${task_id}.json"
    echo '{"status": "in_progress", "iterations": 0, "agents_called": []}' > "$task_file"
    
    while [ $iteration -lt $max_iterations ] && [ "$success" = false ]; do
        iteration=$((iteration + 1))
        log INFO "=== Iteration $iteration of $max_iterations ==="
        
        # 1. ARCHITECT: Design the solution
        log INFO "Phase 1: Architecture"
        local arch_prompt="Design a solution for: $task"
        local arch_output="$STATE_DIR/tasks/${task_id}_architect_${iteration}.json"
        call_agent "architect" "$arch_prompt" "$arch_output"
        
        # 2. CODER: Implement the design
        log INFO "Phase 2: Implementation"
        local design=$(cat "$arch_output" | jq -r '.design // "No design provided"')
        local coder_prompt="Implement based on this design: $design\n\nOriginal task: $task"
        local coder_output="$STATE_DIR/tasks/${task_id}_coder_${iteration}.json"
        call_agent "coder" "$coder_prompt" "$coder_output"
        
        # 3. TESTER: Create tests
        log INFO "Phase 3: Testing"
        local code=$(cat "$coder_output" | jq -r '.files // "No code provided"')
        local tester_prompt="Create tests for: $code\n\nRequirements: $task"
        local tester_output="$STATE_DIR/tasks/${task_id}_tester_${iteration}.json"
        call_agent "tester" "$tester_prompt" "$tester_output"
        
        # 4. REVIEWER: Review everything
        log INFO "Phase 4: Review"
        local reviewer_prompt="Review the implementation:\nDesign: $design\nCode: $code\n\nTask: $task"
        local reviewer_output="$STATE_DIR/tasks/${task_id}_reviewer_${iteration}.json"
        call_agent "reviewer" "$reviewer_prompt" "$reviewer_output"
        
        # 5. DEVIL'S ADVOCATE: Challenge the consensus
        log INFO "Phase 5: Anti-Groupthink Check"
        local consensus="Design approved, code implemented, tests created, review passed"
        local arguments="Design: $design | Review verdict: $(cat "$reviewer_output" | jq -r '.verdict // "unknown"')"
        local devils_output=$(run_devils_advocate "$consensus" "$arguments")
        
        # 6. MANAGER A (CHALLENGER): Final quality gate
        log INFO "Phase 6: Quality Gate"
        local all_outputs="Architect: $(cat "$arch_output") | Coder: $(cat "$coder_output") | Tester: $(cat "$tester_output") | Reviewer: $(cat "$reviewer_output")"
        local concerns=$(cat "$devils_output" | jq -r '.challenges | join(", ")' 2>/dev/null || echo "None")
        local challenger_output=$(run_challenger_review "$task" "$all_outputs" "$concerns")
        
        local verdict=$(jq -r '.verdict' "$challenger_output" 2>/dev/null || echo "UNKNOWN")
        
        if [ "$verdict" = "APPROVE" ]; then
            success=true
            log SUCCESS "Task completed successfully!"
            
            # Move to completed
            mv "$task_file" "$STATE_DIR/completed/${task_id}.json"
            
            # Store successful pattern
            jq -n \
                --arg task "$task" \
                --arg design "$design" \
                --argjson iterations "$iteration" \
                '{task_type: $task, approach: $design, iterations: $iterations, success: true}' \
                > "$STATE_DIR/patterns/success_${task_id}.json"
                
        elif [ "$verdict" = "ESCALATE" ]; then
            log WARN "Task escalated for human review"
            echo "$task_file" >> "$STATE_DIR/tasks/needs_human_review.txt"
            break
        else
            log WARN "Revision requested. Issues: $(jq -r '.issues | join(", ")' "$challenger_output" 2>/dev/null)"
            # Loop will continue to next iteration
        fi
    done
    
    if [ "$success" = false ] && [ $iteration -ge $max_iterations ]; then
        log ERROR "Task failed after $max_iterations iterations"
        echo "$task_file" >> "$STATE_DIR/tasks/failed.txt"
    fi
    
    return $([ "$success" = true ] && echo 0 || echo 1)
}

# Periodic evolution cycle
evolution_cycle() {
    log EVOLVE "=== Starting Evolution Cycle ==="
    
    # Get performance data for each agent
    for agent in architect coder tester reviewer devils_advocate; do
        log EVOLVE "Analyzing $agent..."
        
        # Gather performance metrics (simplified)
        local recent_tasks=$(ls -t "$STATE_DIR/completed/"*.json 2>/dev/null | head -5)
        local performance="Recent tasks: $recent_tasks"
        
        # Run refiner analysis
        local evolution_output=$(run_refiner_check "$agent" "$performance")
        
        # Check if mutations are proposed and confidence is high enough
        local mutations=$(jq -r '.mutations | length' "$evolution_output" 2>/dev/null || echo "0")
        if [ "$mutations" -gt 0 ]; then
            local avg_confidence=$(jq -r '[.mutations[].confidence] | add / length' "$evolution_output" 2>/dev/null || echo "0")
            if (( $(echo "$avg_confidence > 0.7" | bc -l) )); then
                log EVOLVE "Mutations approved for $agent (avg confidence: $avg_confidence)"
                apply_mutations "$evolution_output" "$agent"
            else
                log WARN "Mutations for $agent rejected (low confidence: $avg_confidence)"
            fi
        fi
    done
    
    log SUCCESS "Evolution cycle complete"
}

# Manager mutual review
mutual_oversight_review() {
    log INFO "=== Mutual Oversight Review ==="
    
    # Get recent decisions from both managers
    local challenger_decisions=$(ls -t "$STATE_DIR/tasks/"challenger_*.json 2>/dev/null | head -5 | xargs cat 2>/dev/null || echo "[]")
    local refiner_decisions=$(ls -t "$STATE_DIR/dna/"*_evolution_*.json 2>/dev/null | head -5 | xargs cat 2>/dev/null || echo "[]")
    
    # Challenger reviews Refiner
    log INFO "Challenger reviewing Refiner's decisions..."
    # (Would call the mutual review prompts here)
    
    # Refiner reviews Challenger
    log INFO "Refiner reviewing Challenger's decisions..."
    # (Would call the mutual review prompts here)
    
    log SUCCESS "Mutual oversight review complete"
}

# Create checkpoint
create_checkpoint() {
    local checkpoint_id="checkpoint_${TIMESTAMP}"
    local checkpoint_dir="$STATE_DIR/checkpoints/$checkpoint_id"
    
    mkdir -p "$checkpoint_dir"
    
    cp -r "$STATE_DIR/tasks" "$checkpoint_dir/"
    cp -r "$STATE_DIR/dna" "$checkpoint_dir/"
    cp "$STATE_DIR/shared/"*.json "$checkpoint_dir/"
    cp "$CONFIG_DIR/"*.json "$checkpoint_dir/"
    
    log SUCCESS "Checkpoint created: $checkpoint_id"
    echo "$checkpoint_id"
}

# Restore from checkpoint
restore_checkpoint() {
    local checkpoint_id=$1
    local checkpoint_dir="$STATE_DIR/checkpoints/$checkpoint_id"
    
    if [ ! -d "$checkpoint_dir" ]; then
        log ERROR "Checkpoint not found: $checkpoint_id"
        return 1
    fi
    
    cp -r "$checkpoint_dir/tasks/"* "$STATE_DIR/tasks/"
    cp -r "$checkpoint_dir/dna/"* "$STATE_DIR/dna/"
    cp "$checkpoint_dir/"*.json "$STATE_DIR/shared/"
    
    log SUCCESS "Restored from checkpoint: $checkpoint_id"
}

# Git safety net
git_commit_progress() {
    if [ -d "$PROJECT_DIR/.git" ]; then
        cd "$PROJECT_DIR"
        git add -A
        git commit -m "Night Architecture: Task completed at $(date)" 2>/dev/null || true
    fi
}

# Print status
print_status() {
    echo ""
    echo -e "${CYAN}╔════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║           NIGHT ARCHITECTURE - STATUS                      ║${NC}"
    echo -e "${CYAN}╚════════════════════════════════════════════════════════════╝${NC}"
    
    local completed=$(ls "$STATE_DIR/completed/"*.json 2>/dev/null | wc -l || echo "0")
    local failed=$(wc -l < "$STATE_DIR/tasks/failed.txt" 2>/dev/null || echo "0")
    local patterns=$(ls "$STATE_DIR/patterns/"*.json 2>/dev/null | wc -l || echo "0")
    
    echo -e "  Tasks Completed: ${GREEN}$completed${NC}"
    echo -e "  Tasks Failed:    ${RED}$failed${NC}"
    echo -e "  Patterns Learned: ${CYAN}$patterns${NC}"
    echo ""
}

# Main entry point
main() {
    local task="${1:-}"
    
    if [ -z "$task" ]; then
        echo "Usage: $0 \"task description\""
        echo ""
        echo "Commands:"
        echo "  $0 \"task\"         Run a single task"
        echo "  $0 --evolve        Run evolution cycle only"
        echo "  $0 --status        Show system status"
        echo "  $0 --checkpoint    Create a checkpoint"
        echo "  $0 --restore ID    Restore from checkpoint"
        exit 1
    fi
    
    # Initialize
    init_state
    
    case "$task" in
        --evolve)
            evolution_cycle
            ;;
        --status)
            print_status
            ;;
        --checkpoint)
            create_checkpoint
            ;;
        --restore)
            restore_checkpoint "${2:-}"
            ;;
        --mutual-review)
            mutual_oversight_review
            ;;
        *)
            # Run the task
            print_status
            execute_task "$task"
            
            # Check if evolution should run
            local completed=$(ls "$STATE_DIR/completed/"*.json 2>/dev/null | wc -l || echo "0")
            if [ $((completed % 5)) -eq 0 ] && [ "$completed" -gt 0 ]; then
                log INFO "Triggering periodic evolution cycle..."
                evolution_cycle
            fi
            
            # Git commit on success
            git_commit_progress
            
            print_status
            ;;
    esac
}

# Run main
main "$@"
