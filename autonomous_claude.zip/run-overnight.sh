#!/bin/bash
#
# Night Architecture: Overnight Autonomous Loop
# 
# Run multi-agent development while you sleep!
#
# Usage:
#   ./run-overnight.sh                          # Run with defaults
#   ./run-overnight.sh --max-iterations 50      # Custom iteration limit
#   ./run-overnight.sh --max-hours 8            # Custom time limit
#   ./run-overnight.sh --resume                 # Resume from last checkpoint
#   ./run-overnight.sh --task-file tasks.txt   # Process tasks from file
#

set -euo pipefail

# Configuration
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STATE_DIR="$PROJECT_DIR/state"
CONFIG_DIR="$PROJECT_DIR/config"
LOG_DIR="$STATE_DIR/logs"

# Defaults
MAX_ITERATIONS=50
MAX_HOURS=8
PAUSE_BETWEEN_TASKS=10
EVOLUTION_FREQUENCY=5
MUTUAL_REVIEW_FREQUENCY=10
CHECKPOINT_FREQUENCY=10

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

# Parse arguments
RESUME=false
TASK_FILE=""

while [[ $# -gt 0 ]]; do
    case $1 in
        --max-iterations)
            MAX_ITERATIONS="$2"
            shift 2
            ;;
        --max-hours)
            MAX_HOURS="$2"
            shift 2
            ;;
        --pause)
            PAUSE_BETWEEN_TASKS="$2"
            shift 2
            ;;
        --resume)
            RESUME=true
            shift
            ;;
        --task-file)
            TASK_FILE="$2"
            shift 2
            ;;
        *)
            echo "Unknown option: $1"
            exit 1
            ;;
    esac
done

# Calculate end time
START_TIME=$(date +%s)
MAX_SECONDS=$((MAX_HOURS * 3600))
END_TIME=$((START_TIME + MAX_SECONDS))

# Initialize logging
mkdir -p "$LOG_DIR"
OVERNIGHT_LOG="$LOG_DIR/overnight_$(date +%Y%m%d_%H%M%S).log"

log() {
    local message=$1
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$timestamp] $message" >> "$OVERNIGHT_LOG"
    echo -e "$message"
}

# Banner
show_banner() {
    echo ""
    echo -e "${PURPLE}╔════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${PURPLE}║                                                                ║${NC}"
    echo -e "${PURPLE}║   🦇  NIGHT ARCHITECTURE - OVERNIGHT MODE  🦇                  ║${NC}"
    echo -e "${PURPLE}║                                                                ║${NC}"
    echo -e "${PURPLE}║   Autonomous multi-agent development while you sleep          ║${NC}"
    echo -e "${PURPLE}║                                                                ║${NC}"
    echo -e "${PURPLE}╚════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "  Max Iterations: ${CYAN}$MAX_ITERATIONS${NC}"
    echo -e "  Max Runtime:    ${CYAN}$MAX_HOURS hours${NC}"
    echo -e "  End Time:       ${CYAN}$(date -d @$END_TIME '+%Y-%m-%d %H:%M:%S')${NC}"
    echo ""
}

# Check if we should continue
should_continue() {
    local current_time=$(date +%s)
    local iteration=$1
    
    if [ $iteration -ge $MAX_ITERATIONS ]; then
        log "${YELLOW}⏸ Reached max iterations ($MAX_ITERATIONS)${NC}"
        return 1
    fi
    
    if [ $current_time -ge $END_TIME ]; then
        log "${YELLOW}⏸ Reached max runtime ($MAX_HOURS hours)${NC}"
        return 1
    fi
    
    return 0
}

# Get next task
get_next_task() {
    local iteration=$1
    
    # If task file specified, read from it
    if [ -n "$TASK_FILE" ] && [ -f "$TASK_FILE" ]; then
        local task=$(sed -n "${iteration}p" "$TASK_FILE")
        if [ -n "$task" ]; then
            echo "$task"
            return 0
        fi
    fi
    
    # Otherwise, check for pending tasks in state
    if [ -f "$STATE_DIR/tasks/pending.txt" ]; then
        local task=$(head -n 1 "$STATE_DIR/tasks/pending.txt")
        if [ -n "$task" ]; then
            sed -i '1d' "$STATE_DIR/tasks/pending.txt"  # Remove from queue
            echo "$task"
            return 0
        fi
    fi
    
    # No more tasks
    return 1
}

# Create morning briefing
create_morning_briefing() {
    local briefing_file="$STATE_DIR/morning_briefing_$(date +%Y%m%d).md"
    
    log "${BLUE}Creating morning briefing...${NC}"
    
    # Count results
    local completed=$(ls "$STATE_DIR/completed/"*.json 2>/dev/null | wc -l || echo "0")
    local failed=$(wc -l < "$STATE_DIR/tasks/failed.txt" 2>/dev/null || echo "0")
    local needs_review=$(wc -l < "$STATE_DIR/tasks/needs_human_review.txt" 2>/dev/null || echo "0")
    local patterns=$(ls "$STATE_DIR/patterns/"*.json 2>/dev/null | wc -l || echo "0")
    
    # Calculate runtime
    local end_actual=$(date +%s)
    local runtime_seconds=$((end_actual - START_TIME))
    local runtime_hours=$((runtime_seconds / 3600))
    local runtime_minutes=$(((runtime_seconds % 3600) / 60))
    
    cat > "$briefing_file" << EOF
# 🦇 Night Architecture - Morning Briefing

**Generated:** $(date '+%Y-%m-%d %H:%M:%S')
**Runtime:** ${runtime_hours}h ${runtime_minutes}m

## Summary

| Metric | Count |
|--------|-------|
| Tasks Completed | $completed |
| Tasks Failed | $failed |
| Needs Human Review | $needs_review |
| Patterns Learned | $patterns |

## Tasks Needing Attention

EOF

    if [ -f "$STATE_DIR/tasks/needs_human_review.txt" ] && [ -s "$STATE_DIR/tasks/needs_human_review.txt" ]; then
        echo "### Escalated for Review" >> "$briefing_file"
        while read task_file; do
            echo "- \`$task_file\`" >> "$briefing_file"
        done < "$STATE_DIR/tasks/needs_human_review.txt"
    else
        echo "No tasks need human review! 🎉" >> "$briefing_file"
    fi

    cat >> "$briefing_file" << EOF

## Evolution Progress

The system performed evolution cycles during the night.
Check \`$STATE_DIR/dna/\` for agent configuration changes.

## Recommendations

1. Review any escalated tasks first
2. Check \`$LOG_DIR/overnight_*.log\` for detailed logs
3. Run \`./run-night-architecture.sh --status\` for current state

---
*Sweet dreams were had while agents worked* 🌙
EOF

    log "${GREEN}Morning briefing saved: $briefing_file${NC}"
    echo "$briefing_file"
}

# Main overnight loop
main() {
    show_banner
    
    # Initialize state
    mkdir -p "$STATE_DIR"/{tasks,completed,patterns,dna,checkpoints}
    touch "$STATE_DIR/tasks/failed.txt"
    touch "$STATE_DIR/tasks/needs_human_review.txt"
    
    # Resume handling
    local start_iteration=1
    if [ "$RESUME" = true ]; then
        log "${BLUE}Attempting to resume from last checkpoint...${NC}"
        local latest_checkpoint=$(ls -t "$STATE_DIR/checkpoints/" 2>/dev/null | head -1)
        if [ -n "$latest_checkpoint" ]; then
            log "${GREEN}Resuming from: $latest_checkpoint${NC}"
            # Would restore checkpoint here
            start_iteration=$(jq -r '.iteration // 1' "$STATE_DIR/shared/context.json" 2>/dev/null || echo "1")
        else
            log "${YELLOW}No checkpoint found, starting fresh${NC}"
        fi
    fi
    
    log "${GREEN}🚀 Starting overnight loop at $(date)${NC}"
    
    local iteration=$start_iteration
    local consecutive_failures=0
    local max_consecutive_failures=3
    
    while should_continue $iteration; do
        log ""
        log "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
        log "${CYAN}  ITERATION $iteration / $MAX_ITERATIONS${NC}"
        log "${CYAN}  Time remaining: $(( (END_TIME - $(date +%s)) / 60 )) minutes${NC}"
        log "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
        
        # Get next task
        local task
        if ! task=$(get_next_task $iteration); then
            log "${YELLOW}No more tasks in queue${NC}"
            break
        fi
        
        log "${BLUE}Task: $task${NC}"
        
        # Execute the task
        if ./run-night-architecture.sh "$task" >> "$OVERNIGHT_LOG" 2>&1; then
            log "${GREEN}✓ Task completed successfully${NC}"
            consecutive_failures=0
        else
            log "${RED}✗ Task failed${NC}"
            consecutive_failures=$((consecutive_failures + 1))
            
            if [ $consecutive_failures -ge $max_consecutive_failures ]; then
                log "${RED}⚠ $max_consecutive_failures consecutive failures - pausing for safety${NC}"
                log "${YELLOW}Creating checkpoint and stopping...${NC}"
                ./run-night-architecture.sh --checkpoint
                break
            fi
        fi
        
        # Periodic evolution
        if [ $((iteration % EVOLUTION_FREQUENCY)) -eq 0 ]; then
            log "${PURPLE}🧬 Running evolution cycle...${NC}"
            ./run-night-architecture.sh --evolve >> "$OVERNIGHT_LOG" 2>&1
        fi
        
        # Periodic mutual review
        if [ $((iteration % MUTUAL_REVIEW_FREQUENCY)) -eq 0 ]; then
            log "${PURPLE}👥 Running mutual oversight review...${NC}"
            ./run-night-architecture.sh --mutual-review >> "$OVERNIGHT_LOG" 2>&1
        fi
        
        # Periodic checkpoint
        if [ $((iteration % CHECKPOINT_FREQUENCY)) -eq 0 ]; then
            log "${BLUE}💾 Creating checkpoint...${NC}"
            ./run-night-architecture.sh --checkpoint >> "$OVERNIGHT_LOG" 2>&1
        fi
        
        # Update shared context
        jq --argjson iter "$iteration" '.iteration = $iter' "$STATE_DIR/shared/context.json" > "$STATE_DIR/shared/context.json.tmp"
        mv "$STATE_DIR/shared/context.json.tmp" "$STATE_DIR/shared/context.json"
        
        # Pause between tasks (rate limiting)
        if should_continue $((iteration + 1)); then
            log "${BLUE}Pausing ${PAUSE_BETWEEN_TASKS}s before next task...${NC}"
            sleep $PAUSE_BETWEEN_TASKS
        fi
        
        iteration=$((iteration + 1))
    done
    
    # Create final checkpoint
    log "${BLUE}Creating final checkpoint...${NC}"
    ./run-night-architecture.sh --checkpoint >> "$OVERNIGHT_LOG" 2>&1
    
    # Generate morning briefing
    local briefing=$(create_morning_briefing)
    
    log ""
    log "${GREEN}╔════════════════════════════════════════════════════════════════╗${NC}"
    log "${GREEN}║              OVERNIGHT SESSION COMPLETE                        ║${NC}"
    log "${GREEN}╚════════════════════════════════════════════════════════════════╝${NC}"
    log ""
    log "📋 Morning briefing: $briefing"
    log "📝 Full log: $OVERNIGHT_LOG"
    log ""
    
    # Show summary
    ./run-night-architecture.sh --status
}

# Trap for graceful shutdown
cleanup() {
    log ""
    log "${YELLOW}⚠ Interrupt received - shutting down gracefully...${NC}"
    log "${BLUE}Creating emergency checkpoint...${NC}"
    ./run-night-architecture.sh --checkpoint 2>/dev/null || true
    create_morning_briefing
    log "${GREEN}Safe shutdown complete${NC}"
    exit 0
}

trap cleanup SIGINT SIGTERM

# Run
main
